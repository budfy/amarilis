<?php 
	$mete__title = "";
	$mete__desc  = "";
	$mete__key   = "";
	require($_SERVER['DOCUMENT_ROOT'].'/.cfg.php');
	require($cfg__path.'/template/header.php');
	require($cfg__path.'/template/core/header.php');
?> 


<nav class="nav">
	<div class="nav__menu">
		<div class="full-menu__btn --js">
			<i></i>
			<i></i>
			<i></i>
		</div>
	</div>
	<div class="full-nav flex --align-center">
		<div class="full-nav__wraper">
			<div class="center-wrap">
				123
			</div>
		</div>
	</div>
</nav>

<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1
<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1
<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1
<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1
<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1
<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1
<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1
<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1<br>1


<?php require($cfg__path.'/template/core/footer.php'); ?>
<?php require($cfg__path.'/template/footer.php'); ?>